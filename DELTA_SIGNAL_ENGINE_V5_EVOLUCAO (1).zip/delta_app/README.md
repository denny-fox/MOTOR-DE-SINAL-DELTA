# DELTA SIGNAL ENGINE — V1.2 / V5 evolução (base de desenvolvimento)

Aplicação Flutter local para análise de jogos de futebol. Esta entrega melhora a base recuperada, mas **não deve ser tratada como versão de produção validada** até executar `flutter pub get`, `flutter analyze`, testes e builds Android/iOS num ambiente com SDKs instalados.

## Melhorias nesta entrega

- Persistência local SQLite para jogos e registos de calibração.
- Migração única dos dados antigos guardados em SharedPreferences para SQLite, sem apagar a fonte antiga.
- Motor experimental de probabilidades Poisson para 1X2, over 1.5, over 2.5, ambas marcam e matriz de resultados exatos.
- T01–T05 separados na apresentação: vitória casa, empate, vitória fora, over 1.5, ambas marcam.
- Índice experimental de instabilidade 0–100, explicado como indicador de dispersão e não como probabilidade de surpresa.
- Novo separador **Auxiliar DELTA**, que explica os sinais e destaca riscos com base apenas nos dados locais existentes.
- Backtest anterior que usava o sinal recalculado a partir do jogo final foi desativado como métrica válida. O ecrã explica a razão e orienta para importar sinais históricos registados antes do início.
- Mantidos importação CSV/JSON, filtro SRL/Simulated Reality, histórico e calibração V4 (mínimo de amostra 30; critério de precisão histórica 80%; janelas 5/10/15/20).
- Testes adicionados para verificar limites e soma das probabilidades do modelo.

## Limites importantes

1. O modelo Poisson converte índices manuais de 0–100 em golos esperados através de uma regra provisória. Até ser calibrado com histórico real e validado fora da amostra, as probabilidades são **experimentais**, não previsão comprovada.
2. O auxiliar incluído é local e baseado em regras; **não é um chatbot online**, não consulta a Internet e não tem acesso automático às casas de apostas.
3. Não existe feed de jogos ao vivo nem integração ativa com PremierBet, Angofut ou Elephant Bet. Não foram fornecidas APIs/documentação autorizada.
4. A matriz de resultados exatos é exploratória; não deve ser apresentada como mercado de alta confiança.
5. O backtest honesto exige previsões imutáveis pré-jogo, com timestamp, versão do modelo, entradas e regras de liquidação. Resultados finais por si só não provam que um sinal foi emitido antes do jogo.
6. O armazenamento SQLite usa `sqflite` e está orientado para Android/iOS. O suporte a outras plataformas precisa de uma implementação específica.
7. O projeto ainda precisa de revisão integral de importação, classificação de mercados, liquidação de cada mercado, testes com uma base histórica real e validação de desempenho fora da amostra.

## Importação de jogos

CSV com cabeçalhos suportados, incluindo `home,away,competition,kickoff,home_goals,away_goals` e campos opcionais `homeForm,awayForm,homeAttack,awayAttack,homeDefense,awayDefense`. A hora deve ser fornecida de forma consistente. Não inserir resultados ou métricas inventadas.

## Importação para calibração V4

JSON como lista de objetos ou objeto com `records`/`matches`. Campos esperados: `kickoff`, `signalAt`, `competition`, `home`, `away`, `market`, `threshold`, `predictedOutcome`, `realOutcome`. `signalAt` deve ser anterior ou igual ao pontapé de saída; registos posteriores são rejeitados para evitar fuga de informação. A precisão de 80% é um critério de avaliação, não uma garantia de acerto ou rentabilidade.

## Validação local necessária

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
flutter build appbundle --release
```

Para iOS, executar em macOS com Xcode:

```bash
flutter build ios --release
```

Não se declara que os comandos acima foram executados nesta entrega: o ambiente de trabalho usado para a recuperação não tem Flutter/Dart instalados. Os resultados devem ser registados após execução real.
