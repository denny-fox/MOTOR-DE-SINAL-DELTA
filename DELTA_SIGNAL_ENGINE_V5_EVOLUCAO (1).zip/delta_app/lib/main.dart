import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:csv/csv.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'local_database.dart';
import 'calibration_engine.dart';
import 'probability_engine.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DeltaApp());
}

class DeltaApp extends StatelessWidget {
  const DeltaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'DELTA Signal Engine',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo, brightness: Brightness.dark),
        home: const DeltaHome(),
      );
}

class Match {
  final String home, away, competition;
  final DateTime kickoff;
  final double homeForm, awayForm, homeAttack, awayAttack, homeDefense, awayDefense;
  final int? homeGoals, awayGoals;
  Match({required this.home, required this.away, required this.competition, required this.kickoff,
    this.homeForm = 50, this.awayForm = 50, this.homeAttack = 50, this.awayAttack = 50,
    this.homeDefense = 50, this.awayDefense = 50, this.homeGoals, this.awayGoals});

  bool get played => homeGoals != null && awayGoals != null;
  int get totalGoals => (homeGoals ?? 0) + (awayGoals ?? 0);
  Map<String, dynamic> toJson() => {'home':home,'away':away,'competition':competition,'kickoff':kickoff.toIso8601String(),
    'homeForm':homeForm,'awayForm':awayForm,'homeAttack':homeAttack,'awayAttack':awayAttack,
    'homeDefense':homeDefense,'awayDefense':awayDefense,'homeGoals':homeGoals,'awayGoals':awayGoals};
  factory Match.fromJson(Map<String,dynamic> j) => Match(home:j['home'],away:j['away'],competition:j['competition'],
    kickoff:DateTime.parse(j['kickoff']),homeForm:(j['homeForm']??50).toDouble(),awayForm:(j['awayForm']??50).toDouble(),
    homeAttack:(j['homeAttack']??50).toDouble(),awayAttack:(j['awayAttack']??50).toDouble(),
    homeDefense:(j['homeDefense']??50).toDouble(),awayDefense:(j['awayDefense']??50).toDouble(),
    homeGoals:j['homeGoals'],awayGoals:j['awayGoals']);
}

class DeltaSignal {
  final String market, label, tier;
  final double score;
  final String reason;
  const DeltaSignal(this.market,this.label,this.tier,this.score,this.reason);
}

class DeltaEngine {
  static DeltaProbabilityModel model(Match m) => DeltaProbabilityModel.fromIndices(
    homeForm: m.homeForm, awayForm: m.awayForm,
    homeAttack: m.homeAttack, awayAttack: m.awayAttack,
    homeDefense: m.homeDefense, awayDefense: m.awayDefense,
  );

  static List<DeltaSignal> analyze(Match m) {
    final p = model(m);
    String tier(double v) => v >= 70 ? 'CANDIDATO' : v >= 58 ? 'OBSERVAR' : 'FRACO';
    String pct(double v) => '${(v * 100).toStringAsFixed(1)}%';
    final dc = p.homeWin + p.draw >= p.awayWin + p.draw ? '1X' : 'X2';
    final topScore = p.scoreProbabilities.entries.first;
    return [
      DeltaSignal('T01 • Vitória casa', '1', tier(p.homeWin * 100), p.homeWin * 100, 'Probabilidade Poisson experimental: ${pct(p.homeWin)}.'),
      DeltaSignal('T02 • Empate', 'X', tier(p.draw * 100), p.draw * 100, 'Probabilidade Poisson experimental: ${pct(p.draw)}.'),
      DeltaSignal('T03 • Vitória fora', '2', tier(p.awayWin * 100), p.awayWin * 100, 'Probabilidade Poisson experimental: ${pct(p.awayWin)}.'),
      DeltaSignal('Dupla possibilidade', dc, tier((dc == '1X' ? p.homeWin + p.draw : p.awayWin + p.draw) * 100), (dc == '1X' ? p.homeWin + p.draw : p.awayWin + p.draw) * 100, 'Probabilidade combinada estimada; não é taxa histórica validada.'),
      DeltaSignal('T04 • Mais de 1.5 golos', 'Over 1.5', tier(p.over15 * 100), p.over15 * 100, 'Probabilidade experimental: ${pct(p.over15)}.'),
      DeltaSignal('Golos • Mais de 2.5', 'Over 2.5', tier(p.over25 * 100), p.over25 * 100, 'Probabilidade experimental: ${pct(p.over25)}.'),
      DeltaSignal('T05 • Ambas marcam', 'Sim', tier(p.bttsYes * 100), p.bttsYes * 100, 'Probabilidade experimental: ${pct(p.bttsYes)}.'),
      DeltaSignal('Resultado exato (topo)', topScore.key, 'EXPLORATÓRIO', topScore.value * 100, 'Marcador individual com maior massa no modelo: ${pct(topScore.value)}; mercado de alta variância.'),
      DeltaSignal('Índice de instabilidade', '${p.instability.toStringAsFixed(0)}/100', p.instability >= 60 ? 'ALTO' : p.instability >= 35 ? 'MÉDIO' : 'BAIXO', p.instability, 'Indicador de dispersão do modelo, não é probabilidade de surpresa.'),
    ];
  }

  /// Historical final scores alone cannot establish what was predicted before
  /// kickoff. Until immutable pre-match signals are available, return no valid
  /// backtest metrics rather than score a prediction generated retrospectively.
  static Map<String,double> backtest(List<Match> ms) => {
    'avaliados': 0, 'acertos': 0, 'falhas': 0, 'precisao': 0,
  };
}

class DeltaHome extends StatefulWidget { const DeltaHome({super.key}); @override State<DeltaHome> createState()=>_DeltaHomeState(); }
class _DeltaHomeState extends State<DeltaHome> {
  int tab=0;
  List<Match> matches=[];
  List<CalibrationRecord> calibrationRecords=[];
  bool loading=true;
  final TextEditingController assistantInput=TextEditingController();
  final List<String> assistantMessages=[];
  final calibrationEngine=const DeltaCalibrationEngine(minimumSample:30, minimumPrecision:80);
  final tabs=['Dashboard','Jogos','DELTA T01–T05','Backtest','Histórico','Calibração V4','Auxiliar DELTA'];

  @override void initState(){super.initState(); _load();}
  @override void dispose(){assistantInput.dispose();super.dispose();}
  Future<void> _load() async {
    final db=DeltaLocalDatabase.instance;
    // One-time migration preserves the existing SharedPreferences installation.
    final prefs=await SharedPreferences.getInstance();
    final migrated=await db.read('migration_shared_preferences_v1');
    if(migrated==null) {
      final oldMatches=prefs.getString('matches');
      final oldCalibration=prefs.getString('calibrationRecords');
      if(oldMatches!=null) await db.write('matches',oldMatches);
      if(oldCalibration!=null) await db.write('calibrationRecords',oldCalibration);
      await db.write('migration_shared_preferences_v1','done');
    }
    final raw=await db.read('matches') ?? prefs.getString('matches');
    if(raw!=null) {
      try { matches=(jsonDecode(raw) as List).map((e)=>Match.fromJson(Map<String,dynamic>.from(e as Map))).toList(); }
      catch (_) { matches=[]; }
    }
    final calibrationRaw=await db.read('calibrationRecords') ?? prefs.getString('calibrationRecords');
    if(calibrationRaw!=null) {
      try { calibrationRecords=(jsonDecode(calibrationRaw) as List).map((e)=>CalibrationRecord.fromJson(Map<String,dynamic>.from(e as Map))).where((r)=>r.eligible).toList(); } catch (_) { calibrationRecords=[]; }
    }
    if(mounted) setState(()=>loading=false);
  }
  Future<void> _save() async { await DeltaLocalDatabase.instance.write('matches',jsonEncode(matches.map((e)=>e.toJson()).toList())); }
  Future<void> _saveCalibration() async { await DeltaLocalDatabase.instance.write('calibrationRecords',jsonEncode(calibrationRecords.map((e)=>e.toJson()).toList())); }
  Future<void> importCalibrationJson() async {
    final r=await FilePicker.platform.pickFiles(withData:true,type:FileType.custom,allowedExtensions:['json']);
    if(r==null)return;
    final bytes=r.files.single.bytes; if(bytes==null)return;
    try {
      final decoded=jsonDecode(utf8.decode(bytes));
      final result=calibrationEngine.parseJsonRecords(decoded);
      final known=<String>{for(final x in calibrationRecords) '${x.signalAt.toIso8601String()}|${x.kickoff.toIso8601String()}|${x.home.toLowerCase()}|${x.away.toLowerCase()}|${x.market.toLowerCase()}|${x.threshold}'};
      var added=0;
      for(final x in result.records) {
        final key='${x.signalAt.toIso8601String()}|${x.kickoff.toIso8601String()}|${x.home.toLowerCase()}|${x.away.toLowerCase()}|${x.market.toLowerCase()}|${x.threshold}';
        if(known.add(key)) { calibrationRecords.add(x); added++; }
      }
      calibrationRecords.sort((a,b)=>a.kickoff.compareTo(b.kickoff));
      await _saveCalibration();
      if(mounted) {
        final issueText=result.issues.take(3).map((x)=>'Linha ${x.index}: ${x.message}').join('\n');
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$added registos V4 adicionados; ${result.issues.length} erros. ${issueText}')));
        setState(()=>tab=5);
      }
    } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('JSON de calibração inválido: $e'))); }
  }
  String _normaliseField(String value) => value.toLowerCase().trim().replaceAll(RegExp(r'[\s_\-]+'), '').replaceAll(':', '');
  dynamic _valueFor(Map<String, dynamic> map, List<String> aliases) {
    final normalized = <String, dynamic>{for (final e in map.entries) _normaliseField(e.key): e.value};
    for (final alias in aliases) {
      final value = normalized[_normaliseField(alias)];
      if (value != null && value.toString().trim().isNotEmpty) return value;
    }
    return null;
  }
  DateTime? _parseMatchDate(dynamic value) {
    if (value == null) return null;
    final text=value.toString().trim();
    final iso=DateTime.tryParse(text); if(iso!=null)return iso;
    final match=RegExp(r'^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})(?:\s+(\d{1,2}):(\d{2}))?$').firstMatch(text);
    if(match==null)return null;
    return DateTime(int.parse(match.group(3)!),int.parse(match.group(2)!),int.parse(match.group(1)!),int.tryParse(match.group(4)??'0')??0,int.tryParse(match.group(5)??'0')??0);
  }
  int? _parseGoals(dynamic value) {
    if(value==null || value.toString().trim().isEmpty)return null;
    final text=value.toString().trim();
    final direct=int.tryParse(text); if(direct!=null)return direct;
    final match=RegExp(r'^(\d+)\s*[-:–]\s*(\d+)$').firstMatch(text);
    return match==null?null:int.tryParse(match.group(1)!);
  }
  Future<void> importCsv() async {
    final picked=await FilePicker.platform.pickFiles(withData:true,type:FileType.custom,allowedExtensions:['csv','json']);
    if(picked==null)return;
    final bytes=picked.files.single.bytes; if(bytes==null)return;
    final content=utf8.decode(bytes);
    final extension=picked.files.single.extension?.toLowerCase();
    final imported=<Match>[];
    final issues=<String>[];
    bool isSrl(String competition) => competition.toLowerCase().contains('srl') || competition.toLowerCase().contains('simulated reality') || competition.toLowerCase().contains('realidade simulada');
    void parseRecord(Map<String,dynamic> item, int rowNumber) {
      try {
        final home=(_valueFor(item,['home','home_team','home team','equipa casa','equipa da casa','equipa_casa','mandante'])??'').toString().trim();
        final away=(_valueFor(item,['away','away_team','away team','equipa fora','equipa de fora','equipa_fora','visitante'])??'').toString().trim();
        final competition=(_valueFor(item,['competition','competição','competicao','liga','torneio'])??'').toString().trim();
        final dateValue=_valueFor(item,['kickoff','date','data','data do jogo','data_jogo','datetime','horario','data e hora']);
        final kickoff=_parseMatchDate(dateValue);
        final missing=<String>[];
        if(home.isEmpty)missing.add('equipa da casa');
        if(away.isEmpty)missing.add('equipa de fora');
        if(competition.isEmpty)missing.add('competição');
        if(kickoff==null)missing.add('data válida');
        if(missing.isNotEmpty) { issues.add('Linha $rowNumber: ${missing.join(', ')} em falta ou inválida.'); return; }
        if(isSrl(competition)) { issues.add('Linha $rowNumber: SRL/Simulated Reality excluído.'); return; }
        final homeGoals=_parseGoals(_valueFor(item,['home_goals','homeGoals','golos casa','golos_casa','resultado casa']));
        final awayRaw=_valueFor(item,['away_goals','awayGoals','golos fora','golos_fora','resultado fora']);
        int? awayGoals;
        if(awayRaw!=null) awayGoals=int.tryParse(awayRaw.toString().trim());
        final score=_valueFor(item,['resultado real','resultado_real','score','placar','resultado']);
        if((homeGoals==null || awayGoals==null) && score!=null) {
          final scoreMatch=RegExp(r'^(\d+)\s*[-:–]\s*(\d+)$').firstMatch(score.toString().trim());
          if(scoreMatch!=null) { imported.add(Match(home:home,away:away,competition:competition,kickoff:kickoff!,homeGoals:int.parse(scoreMatch.group(1)!),awayGoals:int.parse(scoreMatch.group(2)!))); return; }
        }
        imported.add(Match(home:home,away:away,competition:competition,kickoff:kickoff!,homeGoals:homeGoals,awayGoals:awayGoals,
          homeForm:double.tryParse('${_valueFor(item,['homeForm','home_form','forma casa'])??50}')??50,
          awayForm:double.tryParse('${_valueFor(item,['awayForm','away_form','forma fora'])??50}')??50,
          homeAttack:double.tryParse('${_valueFor(item,['homeAttack','home_attack','ataque casa'])??50}')??50,
          awayAttack:double.tryParse('${_valueFor(item,['awayAttack','away_attack','ataque fora'])??50}')??50,
          homeDefense:double.tryParse('${_valueFor(item,['homeDefense','home_defense','defesa casa'])??50}')??50,
          awayDefense:double.tryParse('${_valueFor(item,['awayDefense','away_defense','defesa fora'])??50}')??50));
      } catch(e) { issues.add('Linha $rowNumber: registo inválido ($e).'); }
    }
    if(extension=='json') {
      try {
        final decoded=jsonDecode(content);
        final dynamic list=decoded is List?decoded:decoded is Map && decoded['matches'] is List?decoded['matches']:decoded is Map && decoded['records'] is List?decoded['records']:null;
        if(list==null) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('JSON deve ser uma lista ou conter "matches"/"records".'))); return; }
        for(var i=0;i<list.length;i++) {
          if(list[i] is Map) parseRecord(Map<String,dynamic>.from(list[i] as Map),i+1);
          else issues.add('Linha ${i+1}: o registo não é um objeto JSON.');
        }
      } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('JSON inválido: $e'))); return; }
    } else {
      try {
        final rows=const CsvToListConverter().convert(content);
        if(rows.isEmpty) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('CSV vazio.'))); return; }
        final headers=rows.first.map((e)=>_normaliseField(e.toString())).toList();
        final maps=<Map<String,dynamic>>[];
        for(final row in rows.skip(1)) {
          if(row.every((cell)=>cell.toString().trim().isEmpty))continue;
          final map=<String,dynamic>{};
          for(var i=0;i<headers.length && i<row.length;i++) map[headers[i]]=row[i];
          maps.add(map);
        }
        for(var i=0;i<maps.length;i++) parseRecord(maps[i],i+2);
      } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('CSV inválido: $e'))); return; }
    }
    if(imported.isEmpty) {
      final detail=issues.take(4).join('\n');
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Nenhum jogo válido importado. ${issues.length} problemas. $detail')));
      return;
    }
    final merged=<String,Match>{};
    String key(Match m)=>'${m.kickoff.toIso8601String()}|${m.home.toLowerCase().trim()}|${m.away.toLowerCase().trim()}|${m.competition.toLowerCase().trim()}';
    for(final m in matches) merged[key(m)]=m;
    var added=0; var updated=0;
    for(final m in imported) {
      final k=key(m); final old=merged[k];
      if(old==null) { merged[k]=m; added++; }
      else if(m.played || !old.played) { merged[k]=m; updated++; }
    }
    setState(()=>matches=merged.values.toList()..sort((a,b)=>a.kickoff.compareTo(b.kickoff)));
    await _save();
    if(mounted) {
      final detail=issues.take(3).join('\n');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Importação concluída: $added novos, $updated atualizados, ${issues.length} problemas. $detail')));
    }
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return Scaffold(appBar:AppBar(title:const Text('DELTA SIGNAL ENGINE'),actions:[IconButton(tooltip:'Importar jogos CSV/JSON',onPressed:importCsv,icon:const Icon(Icons.upload_file)),IconButton(tooltip:'Importar histórico de calibração V4 JSON',onPressed:importCalibrationJson,icon:const Icon(Icons.fact_check_outlined))]),
      body:Row(children:[NavigationRail(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),labelType:NavigationRailLabelType.all,destinations:[for(final t in tabs) NavigationRailDestination(icon:const Icon(Icons.analytics_outlined),selectedIcon:const Icon(Icons.analytics),label:Text(t))]),Expanded(child:Padding(padding:const EdgeInsets.all(18),child:_page()))]));
  }
  Widget _page(){switch(tab){case 1:return _games();case 2:return _tStages();case 3:return _backtest();case 4:return _history();case 5:return _calibrationPage();case 6:return _assistantPage();default:return _dashboard();}}
  Widget _dashboard(){return ListView(children:[Text('DELTA SIGNAL ENGINE • V5 EVOLUÇÃO',style:Theme.of(context).textTheme.headlineMedium),const SizedBox(height:8),const Text('Motor local para análise, sinais, histórico e calibração. As métricas de backtest só serão apresentadas quando houver sinais pré-jogo auditáveis.'),const SizedBox(height:20),Wrap(spacing:12,runSpacing:12,children:[_card('Jogos registados',matches.length.toString(),Icons.sports_soccer),_card('Sinais de calibração',calibrationRecords.length.toString(),Icons.fact_check),_card('Backtest válido','Pendente',Icons.lock_clock),_card('Feed ao vivo','Não ligado',Icons.cloud_off)]),const SizedBox(height:20),_panel('Pipeline DELTA','T01 vitória casa • T02 empate • T03 vitória fora • T04 over 1.5 • T05 ambas marcam. Poisson experimental → índice de instabilidade → calibração histórica → decisão.'),const SizedBox(height:12),_panel('Integridade dos dados','Sem feed ao vivo nem estatísticas externas verificadas. Índices de forma/ataque/defesa são entradas manuais; probabilidades experimentais não são precisão comprovada.'),]);}
  Widget _card(String a,String b,IconData i)=>SizedBox(width:190,child:Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(i,size:30),const SizedBox(height:12),Text(a),Text(b,style:Theme.of(context).textTheme.headlineSmall)]))));
  Widget _panel(String title,String body)=>Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:8),Text(body)])));
  Widget _games(){return ListView(children:[Text('Jogos',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),for(final m in matches) Card(child:ListTile(title:Text('${m.home} × ${m.away}'),subtitle:Text('${DateFormat('dd/MM HH:mm').format(m.kickoff)} • ${m.competition}'),trailing:Text(m.played?'${m.homeGoals}–${m.awayGoals}':'PRÉ-JOGO')))]);}
  Widget _tStages(){return ListView(children:[Text('DELTA T01–T05',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),for(final m in matches) _matchAnalysis(m)]);}
  Widget _matchAnalysis(Match m){final ss=DeltaEngine.analyze(m); return Card(child:ExpansionTile(title:Text('${m.home} × ${m.away}'),subtitle:Text(m.competition),children:[for(final s in ss)ListTile(title:Text('${s.market}: ${s.label}'),subtitle:Text(s.reason),trailing:Chip(label:Text('${s.tier} • ${s.score.toStringAsFixed(0)}')))]));}
  Widget _backtest(){return ListView(children:[Text('Backtest cronológico',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:16),_panel('Estado: bloqueado para validação honesta','O histórico de resultados, sozinho, não prova qual sinal existia antes do pontapé de saída. A versão anterior gerava o sinal com os dados finais e isso podia introduzir fuga de informação. Por isso, não apresentamos essa métrica como backtest válido.'),const SizedBox(height:12),_panel('O que é necessário','Importar previsões imutáveis registadas antes do jogo, com signalAt, kickoff, mercado, seleção, versão do modelo e resultado real. A calibração V4 já aceita registos com signalAt e rejeita sinais criados depois do início.'),const SizedBox(height:12),FilledButton.icon(onPressed:importCalibrationJson,icon:const Icon(Icons.upload_file),label:const Text('Importar sinais históricos JSON'))]);}

  Widget _calibrationPage(){
    final reports=calibrationEngine.calibrate(calibrationRecords);
    if(calibrationRecords.isEmpty) return ListView(children:[Text('Calibração V4',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),const Text('Ainda não há registos de calibração. Importa um JSON com previsões registadas antes do início dos jogos e os respetivos resultados reais.'),const SizedBox(height:12),FilledButton.icon(onPressed:importCalibrationJson,icon:const Icon(Icons.upload_file),label:const Text('Importar JSON V4')),const SizedBox(height:8),const Text('Campos necessários: kickoff, signalAt, competition, home, away, market, threshold, predictedOutcome e realOutcome.')]);
    return ListView(children:[
      Row(children:[Expanded(child:Text('Calibração V4',style:Theme.of(context).textTheme.headlineSmall)),FilledButton.icon(onPressed:importCalibrationJson,icon:const Icon(Icons.upload_file),label:const Text('Importar JSON'))]),
      const SizedBox(height:8),
      _panel('Regras V4','Amostra mínima: 30 por mercado/segmento/threshold\nPrecisão mínima: 80%\nJanelas: 5, 10, 15 e 20\nConflitos: OBSERVAR\nRegistos elegíveis: ${calibrationRecords.where((r)=>r.eligible).length}'),
      const SizedBox(height:12),
      for(final report in reports) Card(child:ExpansionTile(
        leading:Icon(report.decision==DeltaDecision.entry?Icons.check_circle:report.decision==DeltaDecision.avoid?Icons.cancel:report.decision==DeltaDecision.observe?Icons.visibility:Icons.block),
        title:Text('${decisionLabel(report.decision)} • ${report.market} • ${report.segment}'),
        subtitle:Text('Threshold ${report.threshold}% • n=${report.sample} • precisão ${report.precision.toStringAsFixed(1)}%'),
        children:[Padding(padding:const EdgeInsets.fromLTRB(16,0,16,12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('Acertos: ${report.hits} • Erros/falsos sinais: ${report.falseSignals}'),
          Text('Estabilidade (amplitude das janelas): ${report.stabilitySpread.toStringAsFixed(1)} p.p.'),
          Text('Consistência das janelas: ${report.consistency.toStringAsFixed(1)}%'),
          Text('Conflito: ${report.conflict?'SIM':'não'}'),
          for(final w in report.windows) Text('Últimos ${w.window}: ${w.hits}/${w.sample} • ${w.precision.toStringAsFixed(1)}%'),
          const SizedBox(height:6),Text(report.reason),
        ]))],
      )),
    ]);
  }

  void _askAssistant(){
    final question=assistantInput.text.trim();
    if(question.isEmpty)return;
    final q=question.toLowerCase();
    String answer;
    if(q.contains('srl')||q.contains('simulated')) {
      answer='O DELTA deve excluir SRL/Simulated Reality da análise e da calibração. Confirma também a competição no ficheiro importado.';
    } else if(q.contains('backtest')||q.contains('calibra')) {
      answer='Para uma calibração válida precisamos de sinais guardados antes do pontapé de saída e dos resultados reais. A amostra mínima configurada é 30 por mercado/segmento; 80% é um critério de avaliação, nunca uma garantia.';
    } else if(q.contains('80')||q.contains('precis')) {
      answer='A percentagem do modelo não é a precisão histórica. Só podemos medir precisão comparando previsões pré-jogo imutáveis com resultados reais liquidados e uma amostra suficiente.';
    } else if(q.contains('resultado exacto')||q.contains('resultado exato')||q.contains('2-2')||q.contains('2 a 2')) {
      answer='O resultado exato é um mercado de elevada variância. O DELTA mostra a massa estimada de cada marcador como exploratória; não deve transformar o marcador mais provável numa entrada automática.';
    } else if(q.contains('instabilidade')||q.contains('risco')) {
      answer='O índice 0–100 mede dispersão do modelo, não probabilidade de surpresa. Valor alto significa cautela e deve levar a OBSERVAR, sobretudo se a amostra histórica for insuficiente.';
    } else if(q.contains('odds')||q.contains('odd')||q.contains('premierbet')||q.contains('angofut')||q.contains('elephant')) {
      answer='Neste momento não existe feed nem integração ativa com casas de apostas. Importa odds verificadas manualmente ou fornece documentação/API autorizada; não vou inventar cotações.';
    } else if(q.contains('jogo')||q.contains('equipa')||q.contains('equipes')||q.contains('analis')) {
      answer='Escolhe o jogo no separador DELTA T01–T05. Vou mostrar as estimativas, o índice de instabilidade e as limitações dos dados. Para uma conclusão robusta, precisamos de estatísticas reais e validação histórica do mercado.';
    } else {
      answer='Sou o auxiliar local do DELTA nesta versão. Posso explicar T01–T05, calibração, importação, SRL, instabilidade e limitações do modelo. Não tenho acesso online nem devo inventar dados. Reformula a pergunta dentro desses temas.';
    }
    setState((){assistantMessages.add('Tu: $question');assistantMessages.add('Auxiliar DELTA: $answer');assistantInput.clear();});
  }

  Widget _assistantPage(){
    final upcoming=matches.where((m)=>!m.played).toList()..sort((a,b)=>a.kickoff.compareTo(b.kickoff));
    final recent=upcoming.take(12).toList();
    return ListView(children:[
      Text('Auxiliar DELTA',style:Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height:8),
      const Text('Auxiliar local: explica o modelo, destaca riscos e ajuda a interpretar os dados importados. Não é um chat online nem consulta automaticamente a PremierBet, Angofut ou Elephant Bet.'),
      const SizedBox(height:12),
      _panel('Regras do auxiliar','• Não inventar estatísticas, lesões, odds ou resultados.\n• Sem amostra validada, recomendar OBSERVAR em vez de declarar confiança alta.\n• Instabilidade elevada ou sinais contraditórios reduzem a confiança.\n• Resultado exato é exploratório e tem elevada variância.\n• Nenhum sinal garante lucro ou acerto.'),
      const SizedBox(height:12),
      _panel('Leitura de risco','Probabilidades do motor são experimentais porque os índices de ataque, defesa e forma ainda não foram calibrados contra uma base histórica completa. O limiar de 80% é um critério a testar, não uma promessa.'),
      const SizedBox(height:12),
      Text('Pergunta ao auxiliar',style:Theme.of(context).textTheme.titleLarge),
      const SizedBox(height:8),
      Row(children:[Expanded(child:TextField(controller:assistantInput,decoration:const InputDecoration(border:OutlineInputBorder(),hintText:'Ex.: Como funciona a calibração?'),onSubmitted:(_)=>_askAssistant())),const SizedBox(width:8),IconButton.filled(onPressed:_askAssistant,icon:const Icon(Icons.send),tooltip:'Enviar pergunta')]),
      for(final message in assistantMessages) Padding(padding:const EdgeInsets.symmetric(vertical:4),child:Card(child:Padding(padding:const EdgeInsets.all(12),child:Text(message)))),
      const SizedBox(height:12),
      Text('Próximos jogos registados',style:Theme.of(context).textTheme.titleLarge),
      if(recent.isEmpty) const Padding(padding:EdgeInsets.all(12),child:Text('Não há jogos pré-jogo importados. Importa um CSV/JSON válido para o auxiliar analisar.')),
      for(final m in recent) Builder(builder:(context){
        final p=DeltaEngine.model(m);
        final signal=DeltaEngine.analyze(m).where((s)=>s.market.startsWith('T0')||s.market=='Dupla possibilidade').toList();
        final decision=p.instability>=60?'OBSERVAR — instabilidade alta':p.instability>=35?'OBSERVAR — risco intermédio':'ANÁLISE EXPLORATÓRIA — validar com histórico';
        return Card(child:ExpansionTile(title:Text('${m.home} × ${m.away}'),subtitle:Text('${m.competition} • $decision'),children:[
          ListTile(title:Text('Golos esperados: ${p.homeGoalsExpected.toStringAsFixed(2)} – ${p.awayGoalsExpected.toStringAsFixed(2)}'),subtitle:Text('Instabilidade: ${p.instability.toStringAsFixed(0)}/100')),
          for(final s in signal) ListTile(title:Text('${s.market}: ${s.label}'),subtitle:Text('${s.score.toStringAsFixed(1)}% • ${s.reason}')),
          ListTile(title:const Text('Explicação do auxiliar'),subtitle:Text('Este jogo não deve ser tratado como entrada validada apenas com esta estimativa. Confirma a qualidade dos dados, a amostra histórica do mercado e a estabilidade temporal. O marcador mais provável do modelo é ${p.scoreProbabilities.entries.first.key}, mas a sua probabilidade é apenas exploratória.')),
        ]));
      }),
    ]);
  }

  Widget _history(){return ListView(children:[Text('Histórico',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),FilledButton.icon(onPressed:importCsv,icon:const Icon(Icons.upload_file),label:const Text('Importar CSV')),const SizedBox(height:12),const Text('Formato CSV: home,away,competition,kickoff,home_goals,away_goals'),const SizedBox(height:12),for(final m in matches.where((x)=>x.played))ListTile(title:Text('${m.home} ${m.homeGoals}–${m.awayGoals} ${m.away}'),subtitle:Text(m.competition))]);}
}
