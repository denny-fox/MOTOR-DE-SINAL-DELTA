import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// SQLite key/value store used for local match and calibration JSON payloads.
/// The payload schema stays versioned by the app so existing records can migrate.
class DeltaLocalDatabase {
  DeltaLocalDatabase._();
  static final DeltaLocalDatabase instance = DeltaLocalDatabase._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final root = await getDatabasesPath();
    _database = await openDatabase(
      p.join(root, 'delta_signal_engine.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('CREATE TABLE app_store (store_key TEXT PRIMARY KEY, store_value TEXT NOT NULL, updated_at TEXT NOT NULL)');
      },
    );
    return _database!;
  }

  Future<String?> read(String key) async {
    final db = await database;
    final rows = await db.query('app_store', columns: ['store_value'], where: 'store_key = ?', whereArgs: [key], limit: 1);
    return rows.isEmpty ? null : rows.first['store_value'] as String?;
  }

  Future<void> write(String key, String value) async {
    final db = await database;
    await db.insert('app_store', {'store_key': key, 'store_value': value, 'updated_at': DateTime.now().toUtc().toIso8601String()}, conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
