import 'dart:math';

/// Experimental Poisson model. Inputs are user-provided 0–100 indices, not
/// verified team statistics. Outputs must not be presented as calibrated odds.
class DeltaProbabilityModel {
  final double homeGoalsExpected;
  final double awayGoalsExpected;
  final double homeWin;
  final double draw;
  final double awayWin;
  final double over15;
  final double over25;
  final double bttsYes;
  final double instability;
  final Map<String, double> scoreProbabilities;

  const DeltaProbabilityModel({
    required this.homeGoalsExpected,
    required this.awayGoalsExpected,
    required this.homeWin,
    required this.draw,
    required this.awayWin,
    required this.over15,
    required this.over25,
    required this.bttsYes,
    required this.instability,
    required this.scoreProbabilities,
  });

  factory DeltaProbabilityModel.fromIndices({
    required double homeForm,
    required double awayForm,
    required double homeAttack,
    required double awayAttack,
    required double homeDefense,
    required double awayDefense,
  }) {
    double bounded(double v) => v.clamp(0, 100).toDouble();
    final hf = bounded(homeForm), af = bounded(awayForm);
    final ha = bounded(homeAttack), aa = bounded(awayAttack);
    final hd = bounded(homeDefense), ad = bounded(awayDefense);
    // Index-to-goals mapping is an explicit provisional assumption; it must be
    // calibrated against real historical scores before operational use.
    final homeLambda = (1.25 * pow(max(.15, ha / 50), .65) * exp((50 - ad) / 140) * exp((hf - 50) / 250) * 1.08).clamp(.15, 3.8).toDouble();
    final awayLambda = (1.15 * pow(max(.15, aa / 50), .65) * exp((50 - hd) / 140) * exp((af - 50) / 250)).clamp(.15, 3.8).toDouble();
    final homeP = _poisson(homeLambda, 8);
    final awayP = _poisson(awayLambda, 8);
    double h = 0, d = 0, a = 0, btts = 0, over15 = 0, over25 = 0;
    final scores = <String, double>{};
    for (var i = 0; i < homeP.length; i++) {
      for (var j = 0; j < awayP.length; j++) {
        final p = homeP[i] * awayP[j];
        scores['$i-$j'] = p;
        if (i > j) h += p; else if (i == j) d += p; else a += p;
        if (i > 0 && j > 0) btts += p;
        if (i + j >= 2) over15 += p;
        if (i + j >= 3) over25 += p;
      }
    }
    final total = h + d + a;
    h /= total; d /= total; a /= total;
    final sorted = scores.entries.toList()..sort((x, y) => y.value.compareTo(x.value));
    final topScoreMass = sorted.take(3).fold<double>(0, (s, e) => s + e.value);
    // Instability proxy only: low top-score concentration and a tight 1X2
    // distribution raise caution. It is not an upset probability.
    final max1x2 = max(h, max(d, a));
    final instability = (100 * (0.55 * (1 - max1x2) + 0.45 * (1 - topScoreMass))).clamp(0, 100).toDouble();
    return DeltaProbabilityModel(
      homeGoalsExpected: homeLambda, awayGoalsExpected: awayLambda,
      homeWin: h, draw: d, awayWin: a,
      over15: over15, over25: over25, bttsYes: btts,
      instability: instability,
      scoreProbabilities: Map.unmodifiable(Map.fromEntries(sorted.take(10))),
    );
  }

  static List<double> _poisson(double lambda, int maxGoals) {
    final values = <double>[];
    var p = exp(-lambda);
    values.add(p);
    for (var k = 1; k <= maxGoals; k++) {
      p *= lambda / k;
      values.add(p);
    }
    return values;
  }
}
