/// DELTA V4 calibration primitives.
///
/// A record is only eligible for backtest metrics when the signal timestamp is
/// not later than kickoff and a real outcome is present. No results are inferred.
library delta_calibration_engine;

const List<int> deltaWindows = [5, 10, 15, 20];
const List<int> deltaThresholds = [55, 60, 65, 70, 75, 80];
const List<String> deltaSegments = [
  'Liga', 'Copa', 'Seleções', 'U21', 'U20', 'Amistoso', 'Reservas', 'Outros'
];

enum DeltaDecision { entry, observe, avoid, noEntry }

String decisionLabel(DeltaDecision decision) => switch (decision) {
      DeltaDecision.entry => 'ENTRADA',
      DeltaDecision.observe => 'OBSERVAR',
      DeltaDecision.avoid => 'EVITAR',
      DeltaDecision.noEntry => 'SEM ENTRADA',
    };

class CalibrationRecord {
  final DateTime kickoff;
  final DateTime signalAt;
  final String competition;
  final String home;
  final String away;
  final String market;
  final String predictedOutcome;
  final String? realOutcome;
  final double? odds;
  /// Confidence/threshold recorded at the time of the signal, 0–100.
  final int threshold;
  final String? segmentOverride;

  const CalibrationRecord({
    required this.kickoff,
    required this.signalAt,
    required this.competition,
    required this.home,
    required this.away,
    required this.market,
    required this.predictedOutcome,
    required this.realOutcome,
    required this.threshold,
    this.odds,
    this.segmentOverride,
  });

  bool get hasIdentity => home.trim().isNotEmpty &&
      away.trim().isNotEmpty && competition.trim().isNotEmpty && market.trim().isNotEmpty;
  bool get signalWasTimely => !signalAt.isAfter(kickoff);
  bool get hasRealOutcome => realOutcome != null && realOutcome!.trim().isNotEmpty;
  bool get eligible => hasIdentity && signalWasTimely && hasRealOutcome &&
      predictedOutcome.trim().isNotEmpty && threshold >= 0 && threshold <= 100;

  bool get hit => _normalise(predictedOutcome) == _normalise(realOutcome ?? '');

  String get segment => segmentOverride?.trim().isNotEmpty == true
      ? segmentOverride!.trim()
      : classifySegment(competition);

  String get matchKey => '${kickoff.toIso8601String()}|${_normalise(home)}|${_normalise(away)}';

  static String _normalise(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

  Map<String, dynamic> toJson() => {
        'kickoff': kickoff.toIso8601String(),
        'signalAt': signalAt.toIso8601String(),
        'competition': competition,
        'home': home,
        'away': away,
        'odds': odds,
        'market': market,
        'threshold': threshold,
        'predictedOutcome': predictedOutcome,
        'realOutcome': realOutcome,
        'segment': segmentOverride,
      };

  factory CalibrationRecord.fromJson(Map<String, dynamic> json) {
    DateTime date(String a, String b) {
      final value = json[a] ?? json[b] ?? (a == 'kickoff' ? (json['data'] ?? json['data do jogo'] ?? json['data_jogo']) : (json['data sinal'] ?? json['data_sinal']));
      if (value == null) throw FormatException('Campo de data em falta: $a');
      return DateTime.parse(value.toString());
    }
    String requiredText(List<String> keys, String label) {
      for (final key in keys) {
        final value = json[key]?.toString().trim() ?? '';
        if (value.isNotEmpty) return value;
      }
      throw FormatException('Campo obrigatório em falta: $label');
    }
    final rawThreshold = json['threshold'] ?? json['thresholdPercent'] ?? json['confidence'] ?? json['limiar'] ?? json['confiança'] ?? json['confianca'];
    final threshold = rawThreshold is num ? rawThreshold.round() : int.tryParse('$rawThreshold');
    if (threshold == null) throw const FormatException('Threshold/confiança inválido.');
    final rawOdds = json['odds'];
    final odds = rawOdds == null ? null : double.tryParse(rawOdds.toString().replaceAll(',', '.'));
    return CalibrationRecord(
      kickoff: date('kickoff', 'date'),
      signalAt: date('signalAt', 'signal_at'),
      competition: requiredText(['competition', 'competição', 'liga'], 'competição'),
      home: requiredText(['home', 'home_team', 'equipa casa', 'equipa_casa', 'equipa da casa', 'equipa_da_casa'], 'equipa casa'),
      away: requiredText(['away', 'away_team', 'equipa fora', 'equipa_fora', 'equipa de fora', 'equipa_de_fora'], 'equipa fora'),
      market: requiredText(['market', 'mercado'], 'mercado'),
      predictedOutcome: requiredText(['predictedOutcome', 'predicted_outcome', 'selection', 'selecção', 'selecao'], 'selecção prevista'),
      realOutcome: (json['realOutcome'] ?? json['real_outcome'] ?? json['resultado real'] ?? json['resultado_real'])?.toString(),
      threshold: threshold,
      odds: odds,
      segmentOverride: (json['segment'] ?? json['segmento'])?.toString(),
    );
  }
}

String classifySegment(String competition) {
  final c = competition.toLowerCase();
  if (RegExp(r'\bu21\b|under\s*21|sub.?21').hasMatch(c)) return 'U21';
  if (RegExp(r'\bu20\b|under\s*20|sub.?20').hasMatch(c)) return 'U20';
  if (RegExp(r'reserv|reserve|b team|\bb\b').hasMatch(c)) return 'Reservas';
  if (RegExp(r'amist|friendly|exhibition').hasMatch(c)) return 'Amistoso';
  if (RegExp(r'copa|cup|taça|taca|knock.?out').hasMatch(c)) return 'Copa';
  if (RegExp(r'world cup|euro|qualif|national|international|sele[cç][õo]es?').hasMatch(c)) return 'Seleções';
  if (RegExp(r'league|liga|premier|division|championship|serie [a-z]').hasMatch(c)) return 'Liga';
  return 'Outros';
}

class WindowMetric {
  final int window;
  final int sample;
  final int hits;
  final int misses;
  final double precision;
  const WindowMetric({required this.window, required this.sample, required this.hits, required this.misses, required this.precision});
}

class CalibrationReport {
  final String market;
  final String segment;
  final int threshold;
  final int sample;
  final int hits;
  final int misses;
  final int falseSignals;
  final double precision;
  final double stabilitySpread;
  final double consistency;
  final bool conflict;
  final List<WindowMetric> windows;
  final DeltaDecision decision;
  final String reason;

  const CalibrationReport({required this.market, required this.segment, required this.threshold,
    required this.sample, required this.hits, required this.misses, required this.falseSignals,
    required this.precision, required this.stabilitySpread, required this.consistency,
    required this.conflict, required this.windows, required this.decision, required this.reason});
}

class ImportIssue {
  final int index;
  final String message;
  const ImportIssue(this.index, this.message);
}

class CalibrationImportResult {
  final List<CalibrationRecord> records;
  final List<ImportIssue> issues;
  const CalibrationImportResult(this.records, this.issues);
}

class DeltaCalibrationEngine {
  final int minimumSample;
  final double minimumPrecision;
  final double maximumWindowSpread;

  const DeltaCalibrationEngine({this.minimumSample = 30, this.minimumPrecision = 80, this.maximumWindowSpread = 20});

  /// Strictly parses records and reports every invalid row instead of silently dropping it.
  CalibrationImportResult parseJsonRecords(dynamic decoded) {
    final raw = decoded is List ? decoded :
        decoded is Map && decoded['records'] is List ? decoded['records'] :
        decoded is Map && decoded['matches'] is List ? decoded['matches'] : null;
    if (raw == null) {
      return const CalibrationImportResult([], [ImportIssue(0, 'JSON deve ser uma lista ou conter "records"/"matches" como lista.')]);
    }
    final records = <CalibrationRecord>[];
    final issues = <ImportIssue>[];
    for (var i = 0; i < raw.length; i++) {
      try {
        if (raw[i] is! Map) throw const FormatException('O registo deve ser um objeto JSON.');
        final record = CalibrationRecord.fromJson(Map<String, dynamic>.from(raw[i] as Map));
        if (!record.hasIdentity) throw const FormatException('Equipas, competição e mercado são obrigatórios.');
        if (!record.hasRealOutcome) throw const FormatException('Resultado real em falta; não pode ser usado para calibrar.');
        if (!record.signalWasTimely) throw const FormatException('Sinal criado depois do início do jogo: excluído para evitar fuga de informação futura.');
        if (record.threshold < 0 || record.threshold > 100) throw const FormatException('Threshold deve estar entre 0 e 100.');
        if (record.competition.toLowerCase().contains('srl') || record.competition.toLowerCase().contains('simulated reality')) {
          throw const FormatException('SRL/Simulated Reality é excluído.');
        }
        records.add(record);
      } catch (e) {
        issues.add(ImportIssue(i + 1, e is FormatException ? e.message : 'Registo inválido: $e'));
      }
    }
    return CalibrationImportResult(List.unmodifiable(records), List.unmodifiable(issues));
  }

  List<CalibrationReport> calibrate(List<CalibrationRecord> input) {
    final eligible = input.where((r) => r.eligible &&
      !r.competition.toLowerCase().contains('srl') &&
      !r.competition.toLowerCase().contains('simulated reality')).toList()
      ..sort((a, b) => a.kickoff.compareTo(b.kickoff));
    final reports = <CalibrationReport>[];
    final keys = <String>{};
    for (final r in eligible) { keys.add('${r.market}|${r.segment}'); }
    for (final key in keys) {
      final parts = key.split('|');
      final market = parts.first;
      final segment = parts.sublist(1).join('|');
      final group = eligible.where((r) => r.market == market && r.segment == segment).toList();
      for (final threshold in deltaThresholds) {
        final selected = group.where((r) => r.threshold >= threshold).toList();
        reports.add(_report(market, segment, threshold, selected));
      }
    }
    return reports;
  }

  CalibrationReport _report(String market, String segment, int threshold, List<CalibrationRecord> records) {
    final hits = records.where((r) => r.hit).length;
    final misses = records.length - hits;
    final precision = records.isEmpty ? 0.0 : hits * 100 / records.length;
    final conflict = _hasConflict(records);
    final windows = <WindowMetric>[];
    for (final n in deltaWindows) {
      if (records.length < n) continue;
      final sample = records.sublist(records.length - n);
      final windowHits = sample.where((r) => r.hit).length;
      windows.add(WindowMetric(window: n, sample: n, hits: windowHits, misses: n - windowHits, precision: windowHits * 100 / n));
    }
    final windowValues = windows.map((w) => w.precision).toList();
    final spread = windowValues.isEmpty ? 100.0 : windowValues.reduce((a, b) => a > b ? a : b) - windowValues.reduce((a, b) => a < b ? a : b);
    final consistency = windows.isEmpty ? 0.0 : windows.where((w) => w.precision >= minimumPrecision).length * 100 / windows.length;
    final DeltaDecision decision;
    final String reason;
    if (records.isEmpty) {
      decision = DeltaDecision.noEntry; reason = 'Sem sinais elegíveis para este mercado/segmento/threshold.';
    } else if (conflict) {
      decision = DeltaDecision.observe; reason = 'Existem selecções contraditórias para o mesmo jogo e mercado.';
    } else if (records.length < minimumSample) {
      decision = DeltaDecision.observe; reason = 'Amostra insuficiente: ${records.length}/$minimumSample; não aprovar com poucos dados.';
    } else if (precision < minimumPrecision) {
      decision = DeltaDecision.avoid; reason = 'Precisão histórica ${precision.toStringAsFixed(1)}% abaixo do mínimo de ${minimumPrecision.toStringAsFixed(1)}%.';
    } else if (windows.length < deltaWindows.length || spread > maximumWindowSpread || consistency < 50) {
      decision = DeltaDecision.observe; reason = 'Precisão global suficiente, mas estabilidade/consistência temporal insuficiente.';
    } else {
      decision = DeltaDecision.entry; reason = 'Critérios históricos cumpridos; não garante acertos futuros nem rentabilidade.';
    }
    return CalibrationReport(market: market, segment: segment, threshold: threshold, sample: records.length,
      hits: hits, misses: misses, falseSignals: misses, precision: precision, stabilitySpread: spread,
      consistency: consistency, conflict: conflict, windows: List.unmodifiable(windows), decision: decision, reason: reason);
  }

  bool _hasConflict(List<CalibrationRecord> records) {
    final outcomes = <String, Set<String>>{};
    for (final r in records) {
      final key = '${r.matchKey}|${r.market.toLowerCase()}';
      outcomes.putIfAbsent(key, () => <String>{}).add(r.predictedOutcome.trim().toLowerCase());
    }
    return outcomes.values.any((values) => values.length > 1);
  }
}
