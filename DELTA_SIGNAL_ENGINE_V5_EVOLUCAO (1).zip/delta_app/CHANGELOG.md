# Changelog

## 1.2.0+3 — V5 evolução (base de desenvolvimento)
- SQLite local com migração de dados antigos.
- Motor experimental de probabilidades Poisson e matriz de resultados exatos.
- T01–T05 explícitos na análise.
- Índice experimental de instabilidade.
- Auxiliar DELTA local para interpretação e gestão de risco.
- Métrica de backtest retrospetivo desativada para evitar resultados enganosos.
- Testes unitários iniciais para o motor de probabilidades.
