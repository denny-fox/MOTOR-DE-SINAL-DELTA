import 'package:flutter_test/flutter_test.dart';
import 'package:delta_signal_engine/probability_engine.dart';

void main() {
  test('Poisson probabilities are bounded and 1X2 sums close to 100%', () {
    final model = DeltaProbabilityModel.fromIndices(
      homeForm: 65, awayForm: 45,
      homeAttack: 68, awayAttack: 42,
      homeDefense: 60, awayDefense: 48,
    );
    expect(model.homeWin, inInclusiveRange(0, 1));
    expect(model.draw, inInclusiveRange(0, 1));
    expect(model.awayWin, inInclusiveRange(0, 1));
    expect(model.homeWin + model.draw + model.awayWin, closeTo(1, 0.000001));
    expect(model.over15, inInclusiveRange(0, 1));
    expect(model.over25, inInclusiveRange(0, 1));
    expect(model.bttsYes, inInclusiveRange(0, 1));
    expect(model.scoreProbabilities, isNotEmpty);
  });

  test('instability is within 0–100', () {
    final model = DeltaProbabilityModel.fromIndices(
      homeForm: 50, awayForm: 50,
      homeAttack: 50, awayAttack: 50,
      homeDefense: 50, awayDefense: 50,
    );
    expect(model.instability, inInclusiveRange(0, 100));
  });
}
