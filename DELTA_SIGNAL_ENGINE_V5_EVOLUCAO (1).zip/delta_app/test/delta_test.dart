import 'package:flutter_test/flutter_test.dart';
import 'package:delta_signal_engine/main.dart';

void main() {
  test('backtest reports zero evaluated games when there are no results', () {
    final result = DeltaEngine.backtest([]);
    expect(result['avaliados'], 0);
    expect(result['precisao'], 0);
  });

  test('analysis returns a non-empty signal list for a manually supplied match', () {
    final match = Match(home: 'Casa', away: 'Fora', competition: 'Liga',
      kickoff: DateTime(2026, 10, 13), homeForm: 70, awayForm: 40,
      homeAttack: 65, awayAttack: 45, homeDefense: 60, awayDefense: 40);
    expect(DeltaEngine.analyze(match), isNotEmpty);
  });
}
