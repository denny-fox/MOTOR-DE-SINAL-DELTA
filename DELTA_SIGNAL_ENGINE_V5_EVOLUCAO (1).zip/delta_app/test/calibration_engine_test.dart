import 'package:flutter_test/flutter_test.dart';
import 'package:delta_signal_engine/calibration_engine.dart';

CalibrationRecord record({
  int day = 1,
  String home = 'Casa',
  String away = 'Fora',
  String market = '1X2',
  String predicted = '1',
  String actual = '1',
  int threshold = 80,
  String competition = 'Liga Premier',
  int signalHour = 10,
  int kickoffHour = 12,
}) => CalibrationRecord(
  kickoff: DateTime(2026, 1, day, kickoffHour),
  signalAt: DateTime(2026, 1, day, signalHour),
  competition: competition,
  home: home,
  away: away,
  market: market,
  predictedOutcome: predicted,
  realOutcome: actual,
  threshold: threshold,
);

void main() {
  group('DELTA V4 calibration', () {
    test('uses only signals created before kickoff', () {
      final timely = record();
      final late = record(day: 2, signalHour: 13, kickoffHour: 12);
      expect(timely.eligible, isTrue);
      expect(late.signalWasTimely, isFalse);
      expect(const DeltaCalibrationEngine().calibrate([late]), isEmpty);
    });

    test('does not approve a group with fewer than 30 records', () {
      final records = List.generate(20, (i) => record(day: (i % 28) + 1));
      final reports = const DeltaCalibrationEngine().calibrate(records);
      final report = reports.firstWhere((r) => r.threshold == 80);
      expect(report.sample, 20);
      expect(report.decision, DeltaDecision.observe);
    });

    test('calculates hit rate, false signals and window comparisons', () {
      final records = List.generate(30, (i) => record(
        day: (i % 28) + 1,
        home: 'Casa $i',
        predicted: '1',
        actual: i == 0 ? '2' : '1',
      ));
      final reports = const DeltaCalibrationEngine().calibrate(records);
      final report = reports.firstWhere((r) => r.threshold == 80);
      expect(report.sample, 30);
      expect(report.hits, 29);
      expect(report.falseSignals, 1);
      expect(report.precision, closeTo(96.6667, 0.01));
      expect(report.windows.map((w) => w.window), containsAll([5, 10, 15, 20]));
    });

    test('conflicting selections are OBSERVAR', () {
      final a = record(home: 'Casa A', away: 'Fora A', predicted: '1', actual: '1');
      final b = record(home: 'Casa A', away: 'Fora A', predicted: '2', actual: '1');
      final report = const DeltaCalibrationEngine().calibrate([a, b]).firstWhere((r) => r.threshold == 80);
      expect(report.conflict, isTrue);
      expect(report.decision, DeltaDecision.observe);
    });

    test('JSON import reports missing fields instead of silently dropping rows', () {
      final result = const DeltaCalibrationEngine().parseJsonRecords([
        {'home': 'Casa', 'away': 'Fora'}
      ]);
      expect(result.records, isEmpty);
      expect(result.issues, hasLength(1));
      expect(result.issues.first.message, contains('data'));
    });

    test('excludes SRL records', () {
      final result = const DeltaCalibrationEngine().parseJsonRecords([
        {
          'kickoff': '2026-01-01T12:00:00',
          'signalAt': '2026-01-01T10:00:00',
          'competition': 'SRL League',
          'home': 'Casa', 'away': 'Fora', 'market': '1X2',
          'predictedOutcome': '1', 'realOutcome': '1', 'threshold': 80,
        }
      ]);
      expect(result.records, isEmpty);
      expect(result.issues, hasLength(1));
      expect(result.issues.first.message, contains('SRL'));
    });
  });
}
